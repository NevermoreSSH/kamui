// Dribbble shot by Richard Perez: http://dribbble.com/shots/1343438-Gus-Gif

// Code by Helen V. Holmes
// helenvholmes.co

// Help from these lovely folks:
// http://stackoverflow.com/users/935361/brian-phillips
// http://stackoverflow.com/users/2642616/josh-powell